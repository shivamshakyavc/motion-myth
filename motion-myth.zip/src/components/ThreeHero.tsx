import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { Float, MeshDistortMaterial, Sphere, MeshWobbleMaterial, ContactShadows, Environment, MeshReflectorMaterial, Float as DreiFloat } from '@react-three/drei';
import { useRef, useMemo, useState } from 'react';
import * as THREE from 'three';

function Rig() {
  const { camera, mouse } = useThree();
  const vec = new THREE.Vector3();

  return useFrame(() => {
    camera.position.lerp(vec.set(mouse.x * 1, mouse.y * 0.5, 5), 0.05);
    camera.lookAt(0, 0, 0);
  });
}

function FloatingShapes() {
  const groupRef = useRef<THREE.Group>(null);
  
  const shapes = useMemo(() => [
    { type: 'tetrahedron', pos: [4, 2, -2], color: '#8B5CF6', scale: 0.5 },
    { type: 'torus', pos: [-5, -1, -3], color: '#00FF94', scale: 0.6 },
    { type: 'box', pos: [3, -2, -4], color: '#ffffff', scale: 0.4 },
    { type: 'tetrahedron', pos: [-3, 3, -5], color: '#8B5CF6', scale: 0.3 },
    { type: 'torus', pos: [2, 4, -6], color: '#00FF94', scale: 0.4 },
  ], []);

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y = state.clock.getElapsedTime() * 0.1;
      groupRef.current.rotation.z = state.clock.getElapsedTime() * 0.05;
    }
  });

  return (
    <group ref={groupRef}>
      {shapes.map((s, i) => (
        <DreiFloat key={i} speed={2} rotationIntensity={2} floatIntensity={2}>
          <mesh position={s.pos as any} scale={s.scale}>
            {s.type === 'tetrahedron' && <tetrahedronGeometry args={[1, 0]} />}
            {s.type === 'torus' && <torusGeometry args={[1, 0.2, 16, 100]} />}
            {s.type === 'box' && <boxGeometry args={[1, 1, 1]} />}
            <meshStandardMaterial color={s.color} metalness={0.9} roughness={0.1} transparent opacity={0.4} />
          </mesh>
        </DreiFloat>
      ))}
    </group>
  );
}

function ReflectiveOcean() {
  const meshRef = useRef<THREE.Mesh>(null);
  
  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.z = state.clock.getElapsedTime() * 0.01;
    }
  });

  return (
    <group position={[0, -2.5, 0]}>
      <mesh ref={meshRef} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[100, 100]} />
        <MeshReflectorMaterial
          blur={[400, 100]}
          resolution={1024}
          mixBlur={1}
          mixStrength={100}
          roughness={1}
          depthScale={1.5}
          minDepthThreshold={0.4}
          maxDepthThreshold={1.4}
          color="#050505"
          metalness={0.7}
          mirror={1}
          distortion={0.1}
        />
      </mesh>
    </group>
  );
}

export default function ThreeHero() {
  return (
    <div className="absolute inset-0 z-0">
      <Canvas camera={{ position: [0, 0, 6], fov: 50 }} dpr={[1, 2]} gl={{ alpha: true }}>
        <fog attach="fog" args={['#0A0A0B', 5, 20]} />
        
        <ambientLight intensity={0.2} />
        <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} intensity={2} color="#00FF94" />
        <pointLight position={[-10, -10, -10]} intensity={1} color="#2563EB" />
        <pointLight position={[10, -10, 5]} intensity={1} color="#F59E0B" />
        
        <FloatingShapes />
        <ReflectiveOcean />
        
        <Environment preset="night" />
        <Rig />
      </Canvas>
    </div>
  );
}
