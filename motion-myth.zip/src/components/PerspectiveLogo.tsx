import { useRef } from 'react';
import { motion, useMotionValue, useSpring, useTransform } from 'motion/react';
import MotionMythLogo from './MotionMythLogo';

export default function PerspectiveLogo() {
  const ref = useRef<HTMLDivElement>(null);

  const x = useMotionValue(0);
  const y = useMotionValue(0);

  const mouseX = useSpring(x, { stiffness: 150, damping: 20 });
  const mouseY = useSpring(y, { stiffness: 150, damping: 20 });

  const rotateX = useTransform(mouseY, [-0.5, 0.5], [15, -15]);
  const rotateY = useTransform(mouseX, [-0.5, 0.5], [-15, 15]);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const mouseXPos = e.clientX - rect.left;
    const mouseYPos = e.clientY - rect.top;

    const xPct = mouseXPos / width - 0.5;
    const yPct = mouseYPos / height - 0.5;

    x.set(xPct);
    y.set(yPct);
  };

  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
  };

  return (
    <motion.div
      ref={ref}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }
      }}
      role="button"
      tabIndex={0}
      aria-label="Motion Myth logo - scroll to top"
      style={{
        rotateX,
        rotateY,
        transformStyle: 'preserve-3d',
      }}
      initial="initial"
      whileHover="hover"
      className="flex items-center cursor-pointer perspective-1000 focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-neon rounded-lg p-1"
    >
      <motion.div
        variants={{
          hover: { scale: 1.05, translateZ: 50 },
        }}
      >
        <MotionMythLogo size="small" />
      </motion.div>
    </motion.div>
  );
}
