import { motion } from 'motion/react';

export default function DynamicBg() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
      {/* Primary Glow */}
      <motion.div
        animate={{
          x: ['-20%', '20%', '-20%'],
          y: ['-20%', '20%', '-20%'],
          scale: [1, 1.2, 1],
        }}
        transition={{
          duration: 15,
          repeat: Infinity,
          ease: "linear"
        }}
        className="absolute top-1/4 left-1/4 w-[600px] h-[600px] bg-brand-neon/20 rounded-full blur-[120px]"
      />
      
      {/* Secondary Glow */}
      <motion.div
        animate={{
          x: ['20%', '-20%', '20%'],
          y: ['20%', '-20%', '20%'],
          scale: [1, 1.1, 1],
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "linear"
        }}
        className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-brand-purple/20 rounded-full blur-[100px]"
      />

      {/* Subtle Bottom Accent */}
      <div className="absolute bottom-0 left-0 w-full h-1/2 bg-linear-to-t from-black via-transparent to-transparent z-10" />
    </div>
  );
}
