import { useState } from 'react';
import { motion } from 'motion/react';
import { Menu, X } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import PerspectiveLogo from './PerspectiveLogo';
import RippleEffect from './RippleEffect';

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();
  const isHome = location.pathname === '/';

  const navItems = [
    { name: 'Services', href: isHome ? '#services' : '/#services' },
    { name: 'Portfolio', href: '/portfolio' },
    { name: 'Studio', href: isHome ? '#timeline' : '/#timeline' },
  ];

  return (
    <>
      <nav aria-label="Main navigation" className="fixed top-0 left-0 w-full z-[100] flex items-center justify-between px-6 md:px-12 py-8 bg-linear-to-b from-black/80 to-transparent backdrop-blur-xs">
        <Link to="/">
          <PerspectiveLogo />
        </Link>
        
        <div className="hidden md:flex items-center gap-10 font-display text-xs font-bold uppercase tracking-widest text-gray-400">
          {navItems.map((item) => (
            <RippleEffect 
              key={item.name} 
              href={item.href.startsWith('#') ? item.href : undefined}
              to={!item.href.startsWith('#') ? item.href : undefined}
              className="px-3 py-2 hover:text-white transition-colors"
            >
              {item.name}
            </RippleEffect>
          ))}
          <RippleEffect 
            to="/#contact" 
            className="ml-2 px-6 py-3 bg-linear-to-r from-brand-neon to-brand-purple text-black rounded-sm hover:scale-105 transition-transform duration-300"
          >
            Start Project
          </RippleEffect>
        </div>

        <button 
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          aria-expanded={isMenuOpen}
          aria-label={isMenuOpen ? "Close menu" : "Open menu"}
          aria-controls="mobile-menu"
          className="md:hidden text-white p-2 focus:outline-none focus:ring-2 focus:ring-brand-neon rounded-lg"
        >
          {isMenuOpen ? <X size={32} /> : <Menu size={32} />}
        </button>
      </nav>

      {/* Mobile Menu */}
      <motion.div 
        id="mobile-menu"
        aria-hidden={!isMenuOpen}
        initial={{ x: '100%' }}
        animate={isMenuOpen ? { x: 0 } : { x: '100%' }}
        transition={{ type: 'spring', damping: 25 }}
        className="fixed inset-0 z-[99] bg-dark-surface p-12 flex flex-col justify-center"
      >
        <div className="space-y-6">
          {navItems.concat({ name: 'Contact', href: '/#contact' }).map((item) => (
            <div key={item.name}>
              <RippleEffect 
                href={item.href.startsWith('#') ? item.href : undefined}
                to={!item.href.startsWith('#') ? item.href : undefined}
                onClick={() => setIsMenuOpen(false)}
                className="block text-5xl font-display font-bold tracking-tight hover:text-brand-neon transition-colors w-full text-left"
              >
                {item.name}
              </RippleEffect>
            </div>
          ))}
        </div>
      </motion.div>
    </>
  );
}
