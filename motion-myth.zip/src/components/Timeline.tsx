import { motion, useScroll, useTransform } from 'motion/react';
import { useRef } from 'react';

interface Milestone {
  year: string;
  title: string;
  description: string;
  category: string;
}

const milestones: Milestone[] = [
  {
    year: '2024',
    title: 'Founding of the Myth',
    description: 'Motion Myth was established with a vision to redefine digital storytelling through high-end 3D visual effects.',
    category: 'Studio'
  },
  {
    year: '2025',
    title: 'Cinematic Breakthrough',
    description: 'Partnered with major streaming platforms to deliver VFX for award-winning sci-fi series.',
    category: 'Project'
  },
  {
    year: '2026',
    title: 'Neural Engine Beta',
    description: 'Introduced AI-assisted animation pipelines, reducing turnaround times for complex simulations by 40%.',
    category: 'Tech'
  },
  {
    year: '2027',
    title: 'Global Studio Expansion',
    description: 'Opened headquarters in London and Tokyo, fostering a diverse community of over 50 expert artists.',
    category: 'Growth'
  },
  {
    year: '2028',
    title: 'The Future of Real-Time',
    description: 'Launched the first fully interactive real-time 3D brand experience for a global automotive leader.',
    category: 'Innovation'
  }
];

export default function Timeline() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end end"]
  });

  const lineHeight = useTransform(scrollYProgress, [0, 1], ["0%", "100%"]);

  return (
    <section ref={containerRef} className="px-6 md:px-12 py-32 bg-black relative">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-24">
          <span className="text-brand-neon font-display font-bold uppercase tracking-widest text-sm block mb-4">Our Journey</span>
          <h2 className="text-4xl md:text-6xl font-display font-bold tracking-tight">Timeline of <span className="text-stroke">Innovation</span></h2>
        </div>

        <div className="relative">
          {/* Vertical Line */}
          <div className="absolute left-0 md:left-1/2 top-0 bottom-0 w-px bg-white/10 -translate-x-1/2">
            <motion.div 
              style={{ height: lineHeight }}
              className="w-full bg-brand-neon origin-top"
            />
          </div>

          <div className="space-y-24" role="list">
            {milestones.map((item, index) => (
              <motion.div
                key={index}
                role="listitem"
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                viewport={{ once: true, margin: "-100px" }}
                className={`flex flex-col ${index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'} items-start md:items-center relative`}
              >
                {/* Year Badge */}
                <div className={`flex-1 w-full ${index % 2 === 0 ? 'md:text-right md:pr-16' : 'md:text-left md:pl-16'} mb-8 md:mb-0`}>
                  <span className="text-6xl md:text-8xl font-display font-black text-white/5 uppercase select-none pointer-events-none">
                    {item.year}
                  </span>
                </div>

                {/* Center Node */}
                <div className="absolute left-0 md:left-1/2 top-10 md:top-auto w-4 h-4 bg-black border-2 border-brand-neon rounded-full -translate-x-1/2 z-10 hidden md:block">
                  <motion.div 
                    animate={{ scale: [1, 1.5, 1], opacity: [1, 0.5, 1] }}
                    transition={{ duration: 2, repeat: Infinity }}
                    className="w-full h-full bg-brand-neon rounded-full scale-150 blur-sm"
                  />
                </div>

                {/* Content Card */}
                <div className={`flex-1 w-full ${index % 2 === 0 ? 'md:pl-16' : 'md:pr-16'}`}>
                  <div 
                    data-cursor-text="MYTH"
                    className="p-8 brutalist-border bg-dark-surface/50 backdrop-blur-sm relative group hover:border-brand-neon transition-colors cursor-pointer"
                  >
                    <span className="text-[10px] uppercase tracking-widest font-bold text-brand-neon mb-2 block">{item.category}</span>
                    <h3 className="text-2xl font-display font-bold mb-4">{item.title}</h3>
                    <p className="text-gray-400 leading-relaxed text-sm">{item.description}</p>
                    
                    {/* Decorative Corner */}
                    <div className="absolute top-0 right-0 w-8 h-8 pointer-events-none overflow-hidden">
                      <div className="absolute top-0 right-0 w-[2px] h-full bg-brand-neon translate-y-full group-hover:translate-y-0 transition-transform duration-500" />
                      <div className="absolute top-0 right-0 w-full h-[2px] bg-brand-neon translate-x-full group-hover:translate-x-0 transition-transform duration-500 delay-100" />
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
