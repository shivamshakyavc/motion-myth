import { motion, useMotionValue, useSpring, useTransform } from 'motion/react';
import { ExternalLink, PlayCircle } from 'lucide-react';
import { useState, useRef } from 'react';

const projects = [
  {
    id: 1,
    title: "Nebula Runner",
    category: "3D Animation",
    image: "https://images.unsplash.com/photo-1614728263952-84ea256f9679?q=80&w=1200&auto=format&fit=crop",
    description: "Complex character animation and environment physics for a high-concept sci-fi short.",
    size: "large"
  },
  {
    id: 2,
    title: "Quantum Flow",
    category: "Motion Graphics",
    image: "https://images.unsplash.com/photo-1550684848-fac1c5b4e853?q=80&w=800&auto=format&fit=crop",
    description: "Algorithmic patterns and morphing geometry for tech-focused brand reveals.",
    size: "small"
  },
  {
    id: 3,
    title: "Deep Space VFX",
    category: "Visual Effects",
    image: "https://images.unsplash.com/photo-1462331940025-496dfbfc7564?q=80&w=1200&auto=format&fit=crop",
    description: "Simulating massive cosmic phenomena using advanced particle systems and fluid dynamics.",
    size: "medium"
  },
  {
    id: 4,
    title: "Urban Rhythm",
    category: "Video Editing",
    image: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=800&auto=format&fit=crop",
    description: "High-energy rhythm-based editing for international music and lifestyle culture.",
    size: "medium"
  },
  {
    id: 5,
    title: "Lumina Interface",
    category: "UI/UX Design",
    image: "https://images.unsplash.com/photo-1581291518062-c9a79415c6b9?q=80&w=1200&auto=format&fit=crop",
    description: "Next-gen spatial operating system interface design focusing on depth and motion.",
    size: "large"
  },
  {
    id: 6,
    title: "Bio-Synth Construct",
    category: "3D Animation",
    image: "https://images.unsplash.com/photo-1620641788421-7a1c342ea42e?q=80&w=800&auto=format&fit=crop",
    description: "Detailed organic-mechanical assembly exploration in a digital environment.",
    size: "small"
  }
];

function ProjectCard({ project }: { project: typeof projects[0] }) {
  const containerRef = useRef<HTMLElement>(null);
  const [isHovered, setIsHovered] = useState(false);
  const [isFocused, setIsFocused] = useState(false);
  const x = useMotionValue(0);
  const y = useMotionValue(0);

  const isActive = isHovered || isFocused;

  const mouseXSpring = useSpring(x, { stiffness: 150, damping: 20 });
  const mouseYSpring = useSpring(y, { stiffness: 150, damping: 20 });

  const imageX = useTransform(mouseXSpring, [-0.5, 0.5], ["-8%", "8%"]);
  const imageY = useTransform(mouseYSpring, [-0.5, 0.5], ["-8%", "8%"]);
  
  // For the spotlight effect
  const spotlightX = useTransform(mouseXSpring, [-0.5, 0.5], ["0%", "100%"]);
  const spotlightY = useTransform(mouseYSpring, [-0.5, 0.5], ["0%", "100%"]);

  const handleMouseMove = (e: React.MouseEvent<HTMLElement>) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    x.set(mouseX / width - 0.5);
    y.set(mouseY / height - 0.5);
  };

  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
    setIsHovered(false);
  };

  const handleMouseEnter = () => {
    setIsHovered(true);
  };

  return (
    <motion.article
      ref={containerRef}
      layout
      onMouseMove={handleMouseMove}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onFocus={() => setIsFocused(true)}
      onBlur={() => setIsFocused(false)}
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className={`group relative overflow-hidden bg-gray-950 aspect-square cursor-none focus-within:ring-2 focus-within:ring-brand-neon outline-hidden ${
        project.size === 'large' ? 'md:col-span-2 md:aspect-[21/9]' : ''
      }`}
    >
      {/* Parallax Image */}
      <motion.img 
        src={project.image} 
        alt="" // Decorative image, title is in h3
        role="presentation"
        style={{
          x: imageX,
          y: imageY,
          scale: 1.25
        }}
        className="absolute inset-0 w-full h-full object-cover transition-opacity duration-1000 opacity-40 group-hover:opacity-60 pointer-events-none"
      />
      
      {/* Dynamic Spotlight Overlay */}
      <motion.div 
        className={`absolute inset-0 pointer-events-none z-10 transition-opacity duration-500 ${isActive ? 'opacity-100' : 'opacity-0'}`}
        style={{
          background: useTransform(
            [spotlightX, spotlightY],
            ([sx, sy]) => `radial-gradient(circle at ${sx} ${sy}, rgba(0, 255, 148, 0.15) 0%, transparent 50%)`
          )
        }}
      />

      {/* Main Overlay Gradient */}
      <div className="absolute inset-0 bg-linear-to-t from-black via-black/50 to-transparent opacity-90 pointer-events-none z-20" />
      
      {/* Content Container */}
      <div className="absolute inset-0 p-10 flex flex-col justify-end z-30">
        <motion.div 
          animate={isActive ? { opacity: 1, x: 0 } : { opacity: 1, x: -10 }}
          className="flex items-center gap-3 mb-4"
        >
          <motion.span 
            animate={isActive ? { width: 40 } : { width: 20 }}
            className="h-[1px] bg-brand-neon" 
          />
          <span className="text-brand-neon text-[10px] font-display font-bold uppercase tracking-[0.3em]">
            {project.category}
          </span>
        </motion.div>
        
        <motion.h3 
          animate={isActive ? { color: "#00FF94", y: 0 } : { color: "#FFFFFF", y: 10 }}
          className="text-3xl md:text-5xl font-display font-black uppercase mb-4 tracking-tighter leading-none transition-colors duration-500"
        >
          {project.title}
        </motion.h3>
        
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={isActive ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="text-gray-300 text-sm md:text-base max-w-sm line-clamp-2 font-sans mb-8 leading-relaxed"
        >
          {project.description}
        </motion.p>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={isActive ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="flex items-center gap-8"
        >
          <button 
            aria-label={`View Case Study: ${project.title}`}
            className="flex items-center gap-3 text-white font-display font-bold text-[10px] uppercase tracking-[0.2em] hover:text-brand-neon transition-colors group/btn focus:outline-hidden focus:text-brand-neon"
          >
            <PlayCircle className="w-8 h-8 transform group-hover/btn:scale-110 group-hover/btn:rotate-[360deg] transition-all duration-700" /> 
            <span className="relative overflow-hidden">
              View Case Study
              <span className="absolute bottom-0 left-0 w-full h-[1px] bg-brand-neon transform scale-x-0 group-hover/btn:scale-x-100 transition-transform origin-left duration-300" />
            </span>
          </button>
          
          <button 
            aria-label={`External link to ${project.title}`}
            className="p-3 border border-white/10 rounded-full hover:bg-white hover:text-black hover:border-white transition-all duration-500 hover:scale-110 focus:outline-hidden focus:ring-2 focus:ring-brand-neon"
          >
            <ExternalLink className="w-4 h-4" />
          </button>
        </motion.div>
      </div>

      {/* Decorative Border reveal */}
      <motion.div 
        animate={isActive ? { opacity: 0.3 } : { opacity: 0 }}
        className="absolute inset-0 border border-brand-neon pointer-events-none z-40"
      />
    </motion.article>
  );
}

export default function PortfolioSection() {
  const [filter, setFilter] = useState("All");
  const categories = ["All", "3D Animation", "Motion Graphics", "Visual Effects", "Video Editing", "UI/UX Design"];

  const filteredProjects = filter === "All" 
    ? projects 
    : projects.filter(p => p.category === filter);

  return (
    <section id="portfolio" className="py-32 bg-black relative overflow-hidden">
      {/* Background Accents */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-brand-neon/5 rounded-full blur-[120px] -translate-y-1/2 translate-x-1/4" />
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-brand-purple/5 rounded-full blur-[120px] translate-y-1/2 -translate-x-1/4" />

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-8">
          <div>
            <motion.span 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="text-brand-neon font-display text-xs font-bold uppercase tracking-[0.3em] mb-4 block"
            >
              Selected Works
            </motion.span>
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-5xl md:text-7xl font-display font-black uppercase tracking-tighter"
            >
              Portfolio
            </motion.h2>
          </div>

          <div className="flex flex-wrap gap-4" role="group" aria-label="Filter portfolio by category">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setFilter(cat)}
                aria-pressed={filter === cat}
                className={`px-6 py-2 text-xs font-bold uppercase tracking-widest transition-all duration-300 border ${
                  filter === cat 
                    ? "bg-white text-black border-white" 
                    : "text-gray-400 border-gray-800 hover:border-gray-600"
                } focus:outline-hidden focus:ring-2 focus:ring-brand-neon`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        <motion.div 
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {filteredProjects.map((project) => (
            <ProjectCard key={project.id} project={project} />
          ))}
        </motion.div>
        
        <div className="mt-20 text-center">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-12 py-5 bg-white text-black font-display font-black uppercase tracking-widest text-sm hover:bg-brand-neon transition-colors"
          >
            Explore Full Archive
          </motion.button>
        </div>
      </div>
    </section>
  );
}
