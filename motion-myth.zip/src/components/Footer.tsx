import MotionMythLogo from './MotionMythLogo';

export default function Footer() {
  return (
    <footer className="px-6 md:px-12 py-20 border-t border-white/5 flex flex-col items-center gap-12 bg-black">
      <MotionMythLogo size="normal" />
      
      <div className="flex flex-col md:flex-row justify-between w-full items-center gap-8 text-[10px] uppercase tracking-widest font-bold text-gray-600">
        <div className="flex items-center gap-4">
          <span>&copy; 2026 Motion Myth Studio</span>
          <div className="w-[1px] h-4 bg-white/10 hidden md:block" />
          <span>All Rights Reserved</span>
        </div>
        
        <div className="flex items-center gap-8 italic normal-case font-display text-xs text-gray-400">
          <a href="#" className="hover:text-brand-neon">Privacy Policy</a>
          <a href="#" className="hover:text-brand-neon">Terms of Service</a>
          <a href="#" className="hover:text-brand-neon md:ml-4">Based in London / Global Studio</a>
        </div>
      </div>
    </footer>
  );
}
