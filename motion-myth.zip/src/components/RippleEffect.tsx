import { useState, MouseEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Link } from 'react-router-dom';

interface Ripple {
  x: number;
  y: number;
  id: number;
}

interface RippleEffectProps {
  children: React.ReactNode;
  className?: string;
  href?: string;
  to?: string;
  onClick?: () => void;
  'aria-label'?: string;
}

export default function RippleEffect({ children, className, href, to, onClick, 'aria-label': ariaLabel }: RippleEffectProps) {
  const [ripples, setRipples] = useState<Ripple[]>([]);

  const createRipple = (event: MouseEvent<HTMLElement>) => {
    const container = event.currentTarget.getBoundingClientRect();
    const x = event.clientX - container.left - 50;
    const y = event.clientY - container.top - 50;

    const newRipple = {
      x,
      y,
      id: Date.now(),
    };

    setRipples((prev) => [...prev, newRipple]);
    
    // Auto-remove ripple after animation
    setTimeout(() => {
      setRipples((prev) => prev.filter((r) => r.id !== newRipple.id));
    }, 1000);

    if (onClick) onClick();
  };

  const Component = to ? Link : (href ? 'a' : 'button');
  const props = to ? { to } : { href };

  return (
    <Component
      {...props as any}
      onClick={createRipple as any}
      aria-label={ariaLabel}
      className={`relative overflow-hidden inline-block ${className}`}
    >
      <span className="relative z-10">{children}</span>
      <AnimatePresence>
        {ripples.map((ripple) => (
          <motion.span
            key={ripple.id}
            initial={{ scale: 0, opacity: 0.5 }}
            animate={{ scale: 4, opacity: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="absolute bg-brand-neon/30 rounded-full pointer-events-none z-0"
            style={{
              left: ripple.x,
              top: ripple.y,
              width: 100,
              height: 100,
            }}
          />
        ))}
      </AnimatePresence>
    </Component>
  );
}
