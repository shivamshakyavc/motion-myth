import { motion, Variants } from 'motion/react';

export default function MotionMythLogo({ className = "", size = "normal" }: { className?: string; size?: "small" | "normal" }) {
  const isSmall = size === "small";
  
  const containerVariants: Variants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.1
      }
    }
  };

  const waveVariants: Variants = {
    hidden: { pathLength: 0, opacity: 0 },
    visible: {
      pathLength: 1,
      opacity: 1,
      transition: {
        pathLength: { duration: 1.5, ease: "easeInOut" },
        opacity: { duration: 0.3 }
      }
    }
  };

  const textVariants: Variants = {
    hidden: { y: 10, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.8, ease: "easeOut" }
    }
  };

  return (
    <motion.div 
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true }}
      variants={containerVariants}
      className={`flex flex-col items-center ${className}`}
    >
      {/* The Glowy Wave Logo */}
      <div className={`relative ${isSmall ? 'w-24 h-8 md:w-32 md:h-10' : 'w-48 h-18 md:w-64 md:h-22'} mb-1`}>
        <svg
          viewBox="0 0 400 100"
          className="w-full h-full drop-shadow-[0_0_15px_rgba(0,255,148,0.3)]"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <linearGradient id="waveGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#2563EB" />
              <stop offset="40%" stopColor="#00FF94" />
              <stop offset="60%" stopColor="#FFFFFF" />
              <stop offset="100%" stopColor="#F59E0B" />
            </linearGradient>
            <filter id="glow">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* Background blurred glow layer 1 */}
          <motion.path
            variants={waveVariants}
            d="M20 50 C 60 50, 100 10, 140 50 C 180 90, 220 10, 260 50 C 300 90, 340 50, 380 50"
            stroke="url(#waveGradient)"
            strokeWidth="6"
            strokeLinecap="round"
            opacity="0.2"
            filter="url(#glow)"
            animate={{
              d: [
                "M20 50 C 60 50, 100 15, 140 50 C 180 85, 220 15, 260 50 C 300 85, 340 50, 380 50",
                "M20 50 C 60 50, 100 85, 140 50 C 180 15, 220 85, 260 50 C 300 15, 340 50, 380 50",
                "M20 50 C 60 50, 100 15, 140 50 C 180 85, 220 15, 260 50 C 300 85, 340 50, 380 50"
              ]
            }}
            transition={{
              duration: 4,
              repeat: Infinity,
              ease: "linear",
            }}
          />

          {/* Main Sharp Neon Layer */}
          <motion.path
            variants={waveVariants}
            d="M20 50 C 60 50, 100 20, 140 50 C 180 80, 220 20, 260 50 C 300 80, 340 50, 380 50"
            stroke="url(#waveGradient)"
            strokeWidth="3"
            strokeLinecap="round"
            animate={{
              d: [
                "M20 50 C 60 50, 100 25, 140 50 C 180 75, 220 25, 260 50 C 300 75, 340 50, 380 50",
                "M20 50 C 60 50, 100 75, 140 50 C 180 25, 220 75, 260 50 C 300 25, 340 50, 380 50",
                "M20 50 C 60 50, 100 25, 140 50 C 180 75, 220 25, 260 50 C 300 75, 340 50, 380 50"
              ]
            }}
            transition={{
              duration: 4,
              repeat: Infinity,
              ease: "linear",
            }}
          />
        </svg>
      </div>

      {/* Typography */}
      <motion.div 
        variants={textVariants}
        className={`text-center tracking-[0.3em] font-display ${isSmall ? 'scale-75' : ''}`}
      >
        <h1 className={`${isSmall ? 'text-sm md:text-base' : 'text-xl md:text-2xl'} font-bold text-white uppercase mb-0.5 leading-none`}>
          Motion<span className="text-gray-400">Myth</span>
        </h1>
        <motion.p 
          variants={{
            hidden: { opacity: 0 },
            visible: { opacity: 1, transition: { delay: 1.2 } }
          }}
          className={`${isSmall ? 'text-[6px]' : 'text-[8px] md:text-[10px]'} text-gray-500 uppercase tracking-[0.5em] font-light italic`}
        >
          Studios
        </motion.p>
      </motion.div>
    </motion.div>
  );
}
