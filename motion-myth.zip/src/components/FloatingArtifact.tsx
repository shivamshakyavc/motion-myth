import { Canvas, useFrame } from '@react-three/fiber';
import { Float, MeshDistortMaterial, Octahedron, Environment, MeshWobbleMaterial } from '@react-three/drei';
import { useRef } from 'react';
import * as THREE from 'three';

function Artifact() {
  const groupRef = useRef<THREE.Group>(null);
  const innerRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y = state.clock.getElapsedTime() * 0.5;
    }
    if (innerRef.current) {
      innerRef.current.rotation.x = state.clock.getElapsedTime() * -0.8;
    }
  });

  return (
    <group ref={groupRef}>
      {/* Outer Shell */}
      <Octahedron args={[1.5, 0]} scale={1}>
        <MeshDistortMaterial
          color="#ffffff"
          speed={2}
          distort={0.2}
          wireframe
          transparent
          opacity={0.3}
        />
      </Octahedron>

      {/* Inner Core */}
      <mesh ref={innerRef}>
        <icosahedronGeometry args={[0.8, 1]} />
        <MeshWobbleMaterial
          color="#00FF94"
          speed={3}
          factor={0.6}
          emissive="#00FF94"
          emissiveIntensity={0.5}
          metalness={1}
          roughness={0}
        />
      </mesh>

      {/* Orbiting Ring */}
      <mesh rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[2.2, 0.01, 16, 100]} />
        <meshBasicMaterial color="#00FF94" transparent opacity={0.2} />
      </mesh>
    </group>
  );
}

export default function FloatingArtifact() {
  return (
    <div className="w-full h-[500px]">
      <Canvas camera={{ position: [0, 0, 5], fov: 45 }} dpr={[1, 2]}>
        <ambientLight intensity={0.5} />
        <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} intensity={1} color="#00FF94" />
        <pointLight position={[-10, -10, -10]} color="#8B5CF6" intensity={0.5} />
        
        <Float speed={2} rotationIntensity={1} floatIntensity={1.5}>
          <Artifact />
        </Float>

        <Environment preset="night" />
      </Canvas>
    </div>
  );
}
