import { motion, useMotionValue, useSpring, useTransform, Variants } from 'motion/react';
import { LucideIcon } from 'lucide-react';

interface ServiceCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  index: number;
}

export default function ServiceCard({ title, description, icon: Icon, index }: ServiceCardProps) {
  const x = useMotionValue(0);
  const y = useMotionValue(0);

  const mouseXSpring = useSpring(x);
  const mouseYSpring = useSpring(y);

  const rotateX = useTransform(mouseYSpring, [-0.5, 0.5], ["10deg", "-10deg"]);
  const rotateY = useTransform(mouseXSpring, [-0.5, 0.5], ["-10deg", "10deg"]);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    const xPct = mouseX / width - 0.5;
    const yPct = mouseY / height - 0.5;
    x.set(xPct);
    y.set(yPct);
  };

  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
  };

  const cardVariants: Variants = {
    hidden: { opacity: 0, y: 30 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.8, ease: "easeOut" }
    }
  };

  return (
    <motion.div
      role="article"
      aria-labelledby={`service-title-${index}`}
      variants={cardVariants}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={{
        rotateX,
        rotateY,
        transformStyle: "preserve-3d",
      }}
      className="group relative p-8 bg-dark-surface brutalist-border overflow-hidden transition-all duration-300 hover:border-brand-neon bg-linear-to-b from-white/5 to-transparent"
    >
      <div 
        aria-hidden="true"
        className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity" 
        style={{ transform: "translateZ(50px)" }}
      >
        <Icon size={120} strokeWidth={1} />
      </div>
      
      <div className="relative z-10" style={{ transform: "translateZ(75px)" }}>
        <div 
          aria-hidden="true"
          className="w-12 h-12 flex items-center justify-center rounded-lg bg-white/5 mb-6 group-hover:bg-brand-neon/20 group-hover:text-brand-neon transition-colors"
        >
          <Icon size={24} />
        </div>
        
        <h3 id={`service-title-${index}`} className="text-xl font-display font-bold mb-3 tracking-tight group-hover:text-brand-neon transition-colors">
          {title}
        </h3>
        
        <p className="text-gray-400 text-sm leading-relaxed mb-6 group-hover:text-gray-300 transition-colors">
          {description}
        </p>

        <div className="flex items-center gap-2 text-xs font-display font-medium uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity translate-y-2 group-hover:translate-y-0 duration-300">
          <span>Explore Service</span>
          <div className="w-8 h-[1px] bg-brand-neon" />
        </div>
      </div>
    </motion.div>
  );
}
