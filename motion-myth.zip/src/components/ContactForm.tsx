import { motion, AnimatePresence } from 'motion/react';
import { Send, User, Mail, MessageSquare, Briefcase, Loader2, CheckCircle } from 'lucide-react';
import { useState } from 'react';

export default function ContactForm() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitted(true);
    }, 1500);
  };

  if (submitted) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95, filter: 'blur(10px)' }}
        animate={{ opacity: 1, scale: 1, filter: 'blur(0px)' }}
        role="status"
        aria-live="polite"
        className="p-12 brutalist-border text-center bg-white/5 backdrop-blur-xl relative overflow-hidden"
      >
        <motion.div 
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', damping: 12, stiffness: 200, delay: 0.2 }}
          className="w-20 h-20 bg-brand-neon/20 text-brand-neon rounded-full flex items-center justify-center mx-auto mb-6 relative z-10"
        >
          <CheckCircle size={32} />
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="relative z-10"
        >
          <h3 className="text-3xl font-display font-bold mb-3 uppercase tracking-tight">Transmission <span className="text-brand-neon">Success</span></h3>
          <p className="text-gray-400 max-w-sm mx-auto leading-relaxed">
            Our neural networks are processing your inquiry. A creative agent will establish contact within 24 standard hours.
          </p>
          
          <button 
            onClick={() => setSubmitted(false)}
            className="mt-8 text-[10px] uppercase tracking-widest font-bold text-gray-500 hover:text-white transition-colors"
          >
            Send another transmission
          </button>
        </motion.div>

        {/* Decorative background glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 bg-brand-neon/10 blur-3xl rounded-full" />
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      whileInView={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.6 }}
      viewport={{ once: true }}
      className="p-8 md:p-12 bg-white/5 backdrop-blur-xl brutalist-border relative"
    >
      <div className="absolute top-0 left-0 w-1 h-full bg-brand-neon" />
      
      <h3 className="text-3xl font-display font-bold mb-8 tracking-tight">
        Kickstart Your <span className="text-brand-neon">Legend</span>
      </h3>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label htmlFor="name" className="text-[10px] uppercase tracking-widest font-bold text-gray-500 flex items-center gap-2">
              <User size={12} /> Name
            </label>
            <input
              required
              id="name"
              name="name"
              type="text"
              placeholder="Hideo Kojima"
              autoComplete="name"
              disabled={isSubmitting}
              className="w-full bg-transparent border-b border-white/20 py-3 focus:border-brand-neon outline-hidden transition-colors font-display disabled:opacity-50"
            />
          </div>
          
          <div className="space-y-2">
            <label htmlFor="email" className="text-[10px] uppercase tracking-widest font-bold text-gray-500 flex items-center gap-2">
              <Mail size={12} /> Email
            </label>
            <input
              required
              id="email"
              name="email"
              type="email"
              placeholder="hideo@outerheaven.com"
              autoComplete="email"
              disabled={isSubmitting}
              className="w-full bg-transparent border-b border-white/20 py-3 focus:border-brand-neon outline-hidden transition-colors font-display disabled:opacity-50"
            />
          </div>
        </div>

        <div className="space-y-2">
          <label htmlFor="service" className="text-[10px] uppercase tracking-widest font-bold text-gray-500 flex items-center gap-2">
            <Briefcase size={12} /> Service Type
          </label>
          <select 
            id="service"
            name="service"
            disabled={isSubmitting}
            className="w-full bg-transparent border-b border-white/20 py-3 focus:border-brand-neon outline-hidden transition-colors font-display appearance-none cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <option className="bg-dark-surface">3D Animation</option>
            <option className="bg-dark-surface">Motion Graphics</option>
            <option className="bg-dark-surface">Video Editing</option>
            <option className="bg-dark-surface">Visual Effects</option>
            <option className="bg-dark-surface">3D Modeling</option>
            <option className="bg-dark-surface">UI/UX Design</option>
          </select>
        </div>

        <div className="space-y-2">
          <label htmlFor="brief" className="text-[10px] uppercase tracking-widest font-bold text-gray-500 flex items-center gap-2">
            <MessageSquare size={12} /> Project Brief
          </label>
          <textarea
            required
            id="brief"
            name="brief"
            rows={4}
            disabled={isSubmitting}
            placeholder="Tell us about the dream..."
            className="w-full bg-transparent border-b border-white/20 py-3 focus:border-brand-neon outline-hidden transition-colors font-display resize-none disabled:opacity-50"
          />
        </div>

        <button
          type="submit"
          disabled={isSubmitting}
          aria-busy={isSubmitting}
          className="group relative w-full overflow-hidden bg-white text-black py-4 font-display font-bold uppercase tracking-widest text-sm transition-all enabled:hover:bg-brand-neon disabled:opacity-50 focus:ring-2 focus:ring-brand-neon focus:outline-none cursor-pointer disabled:cursor-not-allowed"
        >
          <AnimatePresence mode="wait">
            {isSubmitting ? (
              <motion.span 
                key="submitting"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="relative z-10 flex items-center justify-center gap-2"
              >
                <Loader2 size={18} className="animate-spin" />
                Transmitting...
              </motion.span>
            ) : (
              <motion.span 
                key="default"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="relative z-10 flex items-center justify-center gap-2"
              >
                Send Message
                <Send size={16} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
              </motion.span>
            )}
          </AnimatePresence>
        </button>
      </form>
    </motion.div>
  );
}
