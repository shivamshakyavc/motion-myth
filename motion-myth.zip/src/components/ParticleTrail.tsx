import { useEffect, useRef } from 'react';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  life: number;
  maxLife: number;
  jitter: number;
}

export default function ParticleTrail() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const particles = useRef<Particle[]>([]);
  const mouse = useRef({ x: 0, y: 0 });
  const lastMouse = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = window.innerWidth;
    let height = window.innerHeight;

    const resize = () => {
      width = window.innerWidth;
      height = window.innerHeight;
      canvas.width = width;
      canvas.height = height;
    };

    window.addEventListener('resize', resize);
    resize();

    const handleMouseMove = (e: MouseEvent) => {
      mouse.current.x = e.clientX;
      mouse.current.y = e.clientY;
    };

    window.addEventListener('mousemove', handleMouseMove);

    const colors = ['#2563EB', '#00FF94', '#FFFFFF', '#F59E0B'];

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      // Spawn particles
      const dx = mouse.current.x - lastMouse.current.x;
      const dy = mouse.current.y - lastMouse.current.y;
      const dist = Math.hypot(dx, dy);
      
      if (dist > 1) {
        const count = Math.min(Math.floor(dist / 3), 8);
        for (let i = 0; i < count; i++) {
          const lerp = i / count;
          const px = lastMouse.current.x + dx * lerp;
          const py = lastMouse.current.y + dy * lerp;
          
          particles.current.push({
            x: px,
            y: py,
            vx: (Math.random() - 0.5) * 1.5,
            vy: (Math.random() - 0.5) * 1.5,
            size: Math.random() * 5 + 3,
            color: colors[Math.floor(Math.random() * colors.length)],
            life: 1,
            maxLife: 1,
            jitter: Math.random() * 0.5 + 0.2
          });
        }
      }

      lastMouse.current.x = mouse.current.x;
      lastMouse.current.y = mouse.current.y;

      // Update and draw particles
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      for (let i = particles.current.length - 1; i >= 0; i--) {
        const p = particles.current[i];
        
        // Zigzag movement logic
        p.vx += (Math.random() - 0.5) * p.jitter;
        p.vy += (Math.random() - 0.5) * p.jitter;
        
        p.x += p.vx;
        p.y += p.vy;
        p.life -= 0.02;
        p.size *= 0.95;

        if (p.life <= 0 || p.size < 0.5) {
          particles.current.splice(i, 1);
          continue;
        }

        // Draw particle with glow
        ctx.save();
        ctx.globalAlpha = p.life * 0.8;
        ctx.shadowBlur = 10;
        ctx.shadowColor = p.color;
        ctx.fillStyle = p.color;
        
        // Slightly rectangular/zigzag shape for some particles
        if (i % 3 === 0) {
            ctx.translate(p.x, p.y);
            ctx.rotate(p.life * 10);
            ctx.fillRect(-p.size/2, -p.size/2, p.size, p.size);
        } else {
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            ctx.fill();
        }
        ctx.restore();

        // Optional ribbon connection for flow
        if (i > 0 && i < particles.current.length - 1) {
            const next = particles.current[i - 1];
            const d = Math.hypot(p.x - next.x, p.y - next.y);
            if (d < 40) {
                ctx.beginPath();
                ctx.moveTo(p.x, p.y);
                ctx.lineTo(next.x, next.y);
                ctx.strokeStyle = p.color;
                ctx.globalAlpha = (1 - d / 40) * p.life * 0.3;
                ctx.lineWidth = p.size / 2;
                ctx.stroke();
            }
        }
      }

      requestAnimationFrame(render);
    };

    const animationId = requestAnimationFrame(render);

    return () => {
      window.removeEventListener('resize', resize);
      window.removeEventListener('mousemove', handleMouseMove);
      cancelAnimationFrame(animationId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-[9999]"
    />
  );
}
