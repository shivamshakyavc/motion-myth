import { motion } from 'motion/react';
import PortfolioSection from '../components/PortfolioSection';

export default function Portfolio() {
  return (
    <motion.main
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen pt-20"
    >
      <div className="bg-black py-20 px-6 md:px-12 text-center">
        <motion.h1 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="text-6xl md:text-8xl font-display font-black uppercase tracking-tighter text-white mb-6"
        >
          Our <span className="text-brand-neon">Work</span>
        </motion.h1>
        <p className="max-w-2xl mx-auto text-gray-400 text-lg">
          A collection of our most ambitious projects, spanning 3D animation, visual effects, and digital craft.
        </p>
      </div>
      <PortfolioSection />
    </motion.main>
  );
}
