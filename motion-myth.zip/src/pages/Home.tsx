import { motion, useScroll, useTransform, AnimatePresence } from 'motion/react';
import { 
  Play, 
  Layers, 
  Cpu, 
  Box, 
  Video, 
  Zap, 
  Sparkles,
  Monitor,
  ChevronRight, 
  Instagram, 
  Twitter, 
  Youtube
} from 'lucide-react';
import { useRef, useState, useEffect } from 'react';
import ThreeHero from '../components/ThreeHero';
import ServiceCard from '../components/ServiceCard';
import ContactForm from '../components/ContactForm';
import RippleEffect from '../components/RippleEffect';
import Timeline from '../components/Timeline';
import Magnetic from '../components/Magnetic';
import FloatingArtifact from '../components/FloatingArtifact';
import DynamicBg from '../components/DynamicBg';

export default function Home() {
  const { scrollYProgress } = useScroll();
  
  // Parallax values
  const heroOpacity = useTransform(scrollYProgress, [0, 0.2], [1, 0]);
  const heroScale = useTransform(scrollYProgress, [0, 0.2], [1, 0.9]);
  const heroY = useTransform(scrollYProgress, [0, 0.2], [0, -100]);

  const phrases = [
    "Turning Ideas Into Epic Motion.",
    "Where Creativity Never Sleeps",
    "The Future of Visual Storytelling"
  ];
  const [currentPhraseIndex, setCurrentPhraseIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentPhraseIndex((prev) => (prev + 1) % phrases.length);
    }, 4500); 
    return () => clearInterval(timer);
  }, []);

  const services = [
    {
      title: "3D Animation",
      description: "Character performance, product visualization, and cinematic storytelling through world-class animation pipelines.",
      icon: Play
    },
    {
      title: "Motion Graphics",
      description: "Dynamic typography, interface elements, and brand identities that leap off the screen with fluid movement.",
      icon: Layers
    },
    {
      title: "Visual Effects",
      description: "Seamless integration of CG elements into reality, from particle simulations to advanced compositing.",
      icon: Zap
    },
    {
      title: "AI Creative Agents",
      description: "Harnessing neural networks for automated character performance and high-fidelity scene generation.",
      icon: Sparkles
    },
    {
      title: "2D Animation",
      description: "Hand-drawn charm meets modern technology for soulful, expressive animated content.",
      icon: Video
    },
    {
      title: "3D Modeling",
      description: "Technically precise and artistically stunning assets for games, advertising, and digital experiences.",
      icon: Box
    },
    {
      title: "Video Editing",
      description: "Rhythmic cutting, tight pacing, and expert post-production to craft compelling narratives from raw footage.",
      icon: Cpu
    },
    {
      title: "UI/UX Design",
      description: "Intuitive user interfaces and engaging experiences designed with a focus on usability and aesthetic excellence.",
      icon: Monitor
    }
  ];

  return (
    <main id="main-content">
      {/* Hero Section */}
      <section className="relative h-screen flex flex-col items-center justify-center p-6 md:p-12 overflow-hidden bg-black">
        <DynamicBg />
        <ThreeHero />
        
        <motion.div 
          style={{ opacity: heroOpacity, scale: heroScale, y: heroY }}
          className="relative z-10 text-center max-w-5xl"
        >
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col items-center"
          >
            <div className="h-[150px] md:h-[200px] flex items-center justify-center mb-8">
              <AnimatePresence mode="wait">
                <motion.h1
                  key={currentPhraseIndex}
                  initial={{ opacity: 0, y: 40, filter: 'blur(12px)' }}
                  animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
                  exit={{ opacity: 0, y: -40, filter: 'blur(12px)' }}
                  transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
                  className="text-3xl md:text-[4vw] font-display font-black leading-[1.1] tracking-tighter uppercase max-w-5xl text-center text-white"
                >
                  {phrases[currentPhraseIndex]}
                </motion.h1>
              </AnimatePresence>
            </div>
            
            <p className="text-gray-300 text-lg md:text-xl max-w-2xl mx-auto font-sans leading-relaxed mb-12">
              Motion Myth transforms ideas into cinematic visuals through high-end 3D animation, motion graphics, VFX, video editing, and immersive storytelling.
            </p>
            
            <div className="flex flex-col md:flex-row items-center justify-center gap-6">
              <Magnetic>
                <RippleEffect 
                  href="#contact" 
                  data-cursor-text="GO"
                  className="w-full md:w-auto px-10 py-5 bg-linear-to-r from-brand-purple to-brand-neon text-white font-display font-bold uppercase tracking-widest text-sm hover:scale-105 transition-all shadow-[0_10px_30px_rgba(139,92,246,0.3)]"
                >
                  Start Your Project
                </RippleEffect>
              </Magnetic>
              <Magnetic>
                <RippleEffect 
                  href="#"
                  data-cursor-text="WATCH"
                  className="w-full md:w-auto px-10 py-5 border border-white/10 bg-white/5 text-white font-display font-bold uppercase tracking-widest text-sm hover:bg-white/10 transition-all backdrop-blur-sm"
                >
                  Watch Showreel
                </RippleEffect>
              </Magnetic>
            </div>
          </motion.div>
        </motion.div>

        {/* Floating Indicator */}
        <motion.div 
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          className="absolute bottom-12 flex flex-col items-center gap-4"
        >
          <span className="text-[10px] uppercase font-bold tracking-widest text-gray-500">Scroll to Explore</span>
          <div className="w-[1px] h-12 bg-linear-to-b from-brand-neon to-transparent" />
        </motion.div>
      </section>

      {/* Services Section */}
      <section id="services" className="px-6 md:px-12 py-32 bg-dark-surface relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-px bg-linear-to-r from-transparent via-white/10 to-transparent" />
        
        {/* Floating background text for depth */}
        <div className="absolute top-40 -left-20 text-[20vw] font-display font-black text-white/2 select-none pointer-events-none uppercase">
          Craft
        </div>

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-8 mb-20">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="max-w-xl"
            >
              <span className="text-brand-neon font-display font-bold uppercase tracking-widest text-sm block mb-4">What we do</span>
              <h2 className="text-4xl md:text-6xl font-display font-bold tracking-tight leading-tight">
                Sculpting Light, <br /> Defining <span className="text-stroke">Motion</span>
              </h2>
            </motion.div>
            <motion.p 
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="text-gray-400 max-w-md"
            >
              From initial blockouts to final frame delivery, our studio specializes in every layer of the digital production pipeline.
            </motion.p>
          </div>

          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={{
              visible: {
                transition: {
                  staggerChildren: 0.1,
                  delayChildren: 0.2
                }
              }
            }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {services.map((service, index) => (
              <ServiceCard key={index} {...service} index={index} />
            ))}
          </motion.div>
        </div>
      </section>

      {/* Client Reel / Logo Cloud */}
      <section className="py-20 bg-black border-y border-white/5 overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 md:px-12 flex flex-col items-center">
          <span className="text-[10px] uppercase tracking-[0.4em] font-bold text-gray-600 mb-12">Trusted by Industry Giants</span>
          <div className="w-full flex flex-wrap justify-center gap-12 md:gap-24 opacity-30 grayscale contrast-150">
            {['SONY', 'MARVEL', 'NETFLIX', 'PIXAR', 'RIOT'].map((client) => (
              <span key={client} className="text-2xl md:text-3xl font-display font-black tracking-tighter hover:text-brand-neon hover:opacity-100 transition-all duration-500 cursor-default">
                {client}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* Project Timeline Section */}
      <section id="timeline">
        <Timeline />
      </section>

      {/* About/Lead Magnet Section */}
      <section className="px-6 md:px-12 py-32 bg-linear-to-b from-dark-surface to-black overflow-hidden relative">
        <div className="absolute right-0 top-1/2 -translate-y-1/2 w-[80vw] h-[80vw] bg-brand-neon/5 rounded-full blur-[120px] pointer-events-none" />
        
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1.2 }}
            viewport={{ once: true }}
            className="order-2 lg:order-1"
          >
            <FloatingArtifact />
          </motion.div>

          <div className="order-1 lg:order-2">
            <h2 className="text-4xl md:text-6xl font-display font-bold mb-8 leading-tight tracking-tight">
              Let's Build Your<br /> Modern <span className="text-brand-neon italic">Artifact</span>
            </h2>
            <p className="text-xl text-gray-400 mb-12 font-sans-light leading-relaxed">
              We don't just render pixels. We build immersive worlds that command attention and drive conversions. Your story deserves the highest level of craftsmanship.
            </p>
            
            <div className="grid grid-cols-2 gap-8 mb-12">
              <div>
                <span className="block text-4xl font-display font-bold text-white mb-2">150+</span>
                <span className="text-xs uppercase tracking-widest text-gray-500 font-bold">Projects Delivered</span>
              </div>
              <div>
                <span className="block text-4xl font-display font-bold text-white mb-2">12</span>
                <span className="text-xs uppercase tracking-widest text-gray-500 font-bold">Global Awards</span>
              </div>
            </div>

            <div className="flex items-center gap-6">
              <a href="#" className="text-white hover:text-brand-neon transition-colors"><Twitter size={24} /></a>
              <a href="#" className="text-white hover:text-brand-neon transition-colors"><Instagram size={24} /></a>
              <a href="#" className="text-white hover:text-brand-neon transition-colors"><Youtube size={24} /></a>
            </div>
          </div>

          <div id="contact">
            <ContactForm />
          </div>
        </div>
      </section>
    </main>
  );
}
